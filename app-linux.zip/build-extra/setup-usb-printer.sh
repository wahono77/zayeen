#!/usr/bin/env bash

set -euo pipefail

SCRIPT_NAME=$(basename "$0")
RULE_FILE="/etc/udev/rules.d/99-escpos.rules"
DEFAULT_GROUP="plugdev"
AUTO_MODE=false
SKIP_GROUP=false
ALLOW_ALL=false
TARGET_USER=""

usage() {
  cat <<EOF
Usage: $SCRIPT_NAME [options]

Configure udev permissions for ESC/POS USB printers.

Options:
  --auto             Non-interactive mode; add rules for detected USB receipt printers.
  --user <name>      Explicit user to add to the $DEFAULT_GROUP group.
  --group <name>     Override target group (default: $DEFAULT_GROUP).
  --skip-group       Do not modify any user/group membership.
  --allow-all        When used with --auto, treat every connected USB device as a printer.
  -h, --help         Show this help message.

Run without options to enter interactive mode and choose a device manually.
EOF
}

parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --auto)
        AUTO_MODE=true
        shift
        ;;
      --user)
        TARGET_USER=${2:-}
        if [[ -z "$TARGET_USER" ]]; then
          echo "Error: --user requires a value." >&2
          exit 1
        fi
        shift 2
        ;;
      --group)
        GROUP_NAME=${2:-}
        if [[ -z "$GROUP_NAME" ]]; then
          echo "Error: --group requires a value." >&2
          exit 1
        fi
        shift 2
        ;;
      --skip-group)
        SKIP_GROUP=true
        shift
        ;;
      --allow-all)
        ALLOW_ALL=true
        shift
        ;;
      -h|--help)
        usage
        exit 0
        ;;
      *)
        echo "Unknown option: $1" >&2
        usage
        exit 1
        ;;
    esac
  done
}

require_command() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "Error: required command '$1' not found. Please install it and rerun this script." >&2
    exit 1
  fi
}

add_rule() {
  local vendor_id="$1"
  local product_id="$2"

  local rule="SUBSYSTEM==\"usb\", ATTR{idVendor}==\"$vendor_id\", ATTR{idProduct}==\"$product_id\", MODE=\"0666\", GROUP=\"$GROUP_NAME\""

  touch "$RULE_FILE"
  if grep -Fq "$vendor_id\", ATTR{idProduct}==\"$product_id" "$RULE_FILE"; then
    echo "Rule for ${vendor_id}:${product_id} already exists in $RULE_FILE. Skipping."
  else
    {
      echo "# Added by $SCRIPT_NAME on $(date '+%Y-%m-%d %H:%M:%S')"
      echo "$rule"
    } >>"$RULE_FILE"
    echo "Added udev rule for device ${vendor_id}:${product_id}."
  fi
}

sanitize_user() {
  local candidate="$1"
  if [[ -n "$candidate" && "$candidate" != "root" ]]; then
    echo "$candidate"
  fi
}

determine_target_user() {
  if [[ -n "$TARGET_USER" ]]; then
    return
  fi

  local candidate=""
  candidate=$(sanitize_user "${SUDO_USER:-}")
  if [[ -z "$candidate" ]]; then
    candidate=$(sanitize_user "$(logname 2>/dev/null || true)")
  fi
  if [[ -z "$candidate" ]]; then
    # fallback: first real user (uid >= 1000)
    candidate=$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1; exit}' /etc/passwd)
  fi

  if [[ -n "$candidate" ]]; then
    TARGET_USER="$candidate"
  fi
}

maybe_add_user_to_group() {
  if $SKIP_GROUP; then
    echo "Skipping group membership update (requested)."
    return
  fi

  determine_target_user

  if [[ -z "$TARGET_USER" ]]; then
    echo "Could not determine a non-root user to add to group '$GROUP_NAME'."
    echo "Please rerun this script manually with '--user <name>' after installation if needed."
    return
  fi

  if ! getent group "$GROUP_NAME" >/dev/null 2>&1; then
    echo "Group '$GROUP_NAME' does not exist. Creating..."
    groupadd "$GROUP_NAME"
  fi

  if id -nG "$TARGET_USER" | tr ' ' '\n' | grep -qx "$GROUP_NAME"; then
    echo "User '$TARGET_USER' already belongs to '$GROUP_NAME'."
  else
    echo "Adding user '$TARGET_USER' to group '$GROUP_NAME'..."
    usermod -aG "$GROUP_NAME" "$TARGET_USER"
    echo "User '$TARGET_USER' added. They must log out and back in for the new permissions to apply."
  fi
}

reload_udev() {
  udevadm control --reload-rules
  udevadm trigger
}

adjust_chrome_sandbox() {
  local script_dir
  local app_dir
  script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
  app_dir=$(dirname "$script_dir")
  local sandbox_path="$app_dir/chrome-sandbox"

  if [[ -f "$sandbox_path" ]]; then
    chown root:root "$sandbox_path" 2>/dev/null || true
    chmod 4755 "$sandbox_path" 2>/dev/null || true
  fi
}

list_usb_devices() {
  lsusb
}

filter_device_line() {
  local line="$1"
  local allow_any=${2:-false}
  local id_field=${line#*ID }
  id_field=${id_field%% *}

  if [[ "$id_field" != *:* ]]; then
    echo ""
    return
  fi

  local vendor_id=${id_field%%:*}
  local product_id=${id_field##*:}

  # Skip Linux Foundation root hubs (1d6b)
  if [[ "$vendor_id" == "1d6b" ]]; then
    echo ""
    return
  fi

  if ! $ALLOW_ALL && ! $allow_any; then
    local description
    description=$(echo "$line" | tr '[:upper:]' '[:lower:]')
    if ! grep -Eq 'printer|pos|receipt|escpos|epson|bixolon|star' <<<"$description"; then
      echo ""
      return
    fi
  fi

  echo "${vendor_id}:${product_id}"
}

interactive_mode() {
  mapfile -t devices < <(list_usb_devices)

  if [[ ${#devices[@]} -eq 0 ]]; then
    echo "No USB devices detected. Connect your printer and try again." >&2
    exit 1
  fi

  echo "Detected USB devices:"
  for idx in "${!devices[@]}"; do
    printf " [%d] %s\n" "$((idx + 1))" "${devices[$idx]}"
  done

  echo
  read -rp "Select the printer number to configure: " selection

  if ! [[ "$selection" =~ ^[0-9]+$ ]] || (( selection < 1 || selection > ${#devices[@]} )); then
    echo "Invalid selection. Aborting." >&2
    exit 1
  fi

  local selected_line=${devices[$((selection - 1))]}
  local ids
  ids=$(filter_device_line "$selected_line" true)

  if [[ -z "$ids" ]]; then
    echo "Unable to parse vendor/product from: $selected_line" >&2
    exit 1
  fi

  local vendor_id=${ids%%:*}
  local product_id=${ids##*:}

  echo
  echo "Configuring USB rule for device:"
  echo "  Vendor ID : $vendor_id"
  echo "  Product ID: $product_id"
  echo

  add_rule "$vendor_id" "$product_id"
}

auto_mode() {
  mapfile -t devices < <(list_usb_devices)

  if [[ ${#devices[@]} -eq 0 ]]; then
    echo "No USB devices detected. Skipping automatic rule creation." >&2
    return
  fi

  local added_any=false
  for line in "${devices[@]}"; do
    local ids
    ids=$(filter_device_line "$line")
    if [[ -z "$ids" ]]; then
      continue
    fi
    local vendor_id=${ids%%:*}
    local product_id=${ids##*:}
    add_rule "$vendor_id" "$product_id"
    added_any=true
  done

  if ! $added_any; then
    echo "No suitable USB printers detected. Please connect your printer and rerun this script manually."
  fi
}

main() {
  GROUP_NAME="$DEFAULT_GROUP"
  parse_args "$@"

  require_command lsusb
  require_command udevadm

  if [[ $EUID -ne 0 ]]; then
    echo "Re-running $SCRIPT_NAME with elevated privileges..."
    exec sudo "$0" "$@"
  fi

  if $AUTO_MODE; then
    auto_mode
  else
    interactive_mode
  fi

  adjust_chrome_sandbox
  reload_udev
  maybe_add_user_to_group

  echo
  echo "Done. Unplug and reconnect the printer, then retry printing."
  if ! $SKIP_GROUP && [[ -n "$TARGET_USER" ]]; then
    echo "If printing still fails, ensure user '$TARGET_USER' has logged out/in to refresh group membership."
  fi
}

main "$@"
